<html>
<head> <title>Formulario</title></head>
<body>
<h1>Formulario Velocidad </h1>
<form action="ej9velo.php" method="post">
    <div>
    Distancia: <input type="text" name="$distancia"> <select name="$medida"><option>Metros</option><option>Kilometros</option></select> <br>
    Tiempo: <input type="text" name="$tiempo"><select name="$medirtiempo"><option>Segundos</option><option>Horas</option></select> <br>
     
     <input type="submit" value="Calcular">
     <input type="submit" name="Esborra" value="borrar">
     </div>
</form>
</body>
</html>