<html>
<head> <title>Ejemplo 5</title></head>
<body>
 <h1> Ejemplo de Formulario 2 </h1>

<form action="ej12.php" method="post">
     Nombre: <input type="text" name="personal[name]">

     E-mail: <input type="text" name="personal[email]">

     Cerveza: <br>
     <select multiple name="beer[]">
         <option value="warthog">Warthog
         <option value="guinness">Guinness
         <option value="stuttgarter">Stuttgarter Schwabenbräu
     </select>
     <input type="submit">
 </form>
</body>
</html>