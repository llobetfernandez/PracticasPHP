<html>
<head> <title>Formulario</title></head>
<body>
 <h1>Nombres de personas</h1>
 <form action="ej8comproba.php" method="post">
<?php
    $cant=$_POST["cantidad"];
     for ($i=1;$i<=$cant;$i++){
        $t=$i-1;
        print  "$i Nombre: <input name='nom[$t]'>Hombre: <input type='radio' name='genero[$t]' value='Hombre[$t]'> Mujer: <input type='radio' name='genero[$t]' value='Mujer[$t]'>"; print "<br>";
       
        }
        
        ?>
    <input type="submit" name="comprobar">
    <input type="submit" name="esborrar">
</form>
<br>

<a href="m07u01l01ej8.php">Volver al formulario</a>
</body>
</html>