<html>
<head> <title>Formulario</title></head>
<body>
<h1>Resultado Velocidad </h1>
<?php
    $distancia=$_POST['$distancia'];
    $medida=$_POST['$medida'];
    $tiempo=$_POST['$tiempo'];
    $medirtiempo=$_POST['$medirtiempo'];
    $num=$distancia/$tiempo;
    $numb=($distancia*1000)/($tiempo*3600);
    if ($medida=="Metros"){
        $cadena="m";
        if ($medirtiempo=="Segundos"){
            $cadenab="s";
            print "Si ha recorrido $distancia $cadena en $tiempo $cadenab su velocidad media ha sido $num $cadena / $cadenab ($numb Km / h)";
        }
        elseif($medirtiempo=="Horas"){
            $cadenad="h";
            print "Si ha recorrido $distancia $cadena en $tiempo $cadenad su velocidad media ha sido $num $cadena / $cadenad ($numb Km / s)";
        }
    }
    else
    {
        $cadenac="Km";
        if ($medirtiempo=="Segundos"){
            $cadenab="s";
            print "Si ha recorrido $distancia $cadenac en $tiempo $cadenab su velocidad media ha sido $num $cadenac / $cadenab ($numb m / h)";
        }
        elseif($medirtiempo=="Horas"){
            $cadenad="h";
            print "Si ha recorrido $distancia $cadenac en $tiempo $cadenad su velocidad media ha sido $num $cadenac / $cadenad ($numb m / s)";
        }
        
    }
    
?>

<br>

<a href="m07u01l01ej9.php">Volver al formulario inicial</a>

</body>
</html>