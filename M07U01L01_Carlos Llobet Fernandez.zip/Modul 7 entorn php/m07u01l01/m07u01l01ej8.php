<html>
<head> <title>Formulario</title></head>
<body>
<h1>Formulario </h1>
 <?php
 echo "Escribe un numero de 0 mayor que numero menor o igual a 10 y dibujare una tabla de 2 columnas y botones radio";
?>
<form action="ej8.php" method="post">
    <div>
     cantidad: <input type="text" name="cantidad"> <br>
     <input type="submit" value="Comprobar">
     <input type="submit" name="Esborra" value="borrar">
     </div>
 </form> 
 <?php
    if ($submit=true) {
    }else{clear();}
    
 ?>

</body>
</html>