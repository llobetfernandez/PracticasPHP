<html>
<head> <title>Ejemplo 2 </title></head>
<body>
 <h1> Ejemplo de PHP </h1>

<?php
 /* Asignando una cadena. */
 $str = "Esto es una cadena";

 /* A�adiendo a la cadena. */
 $str = $str . " con algo m�s de texto";

 /* Otra forma de a�adir, incluye un car�cter de nueva l�nea  */
 $str .= " Y un car�cter de nueva l�nea al final.\n";
 print "$str <br>\n";

 /* Esta cadena terminar� siendo '<p>N�mero: 9</p>' */
 $num = 9;
 $str = "<p>N�mero: $num</p>";
 print "$str <br>\n";

 /* Esta ser� '<p>N�mero: $num</p>' */
 $num = 9;
 $str = "<p>N�mero: $num</p>";
 print "$str <br>\n";

 /* Obtener el primer car�cter de una cadena  como una vector*/
 $str = 'Esto es una prueba.';
 $first = $str[0];
 print "$str 0->$first <br>\n";

 /* Obtener el �ltimo car�cter de una cadena. */
 $str = 'Esto es a�n una prueba.';
 $last = $str[strlen($str)-1];
 print "$str last->$last <br>\n";
 ?>

</body>
</html>
