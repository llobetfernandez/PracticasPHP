<html>
<head> <title>Ejemplo 4_1</title></head>
<body>
 <h1> Ejemplo de PHP </h1>

<?php
print "<h2>Hola "; echo $_POST["nombre"]; print "</h2>\n";

?>

<br>

<a href="m07u01l01ej4a.php">Volver al formulario</a>
</body>
</html>