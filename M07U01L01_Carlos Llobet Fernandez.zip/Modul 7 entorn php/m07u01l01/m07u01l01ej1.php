<html>
<head> <title>Ejemplo 1 </title></head>
<body>
 <h1> Ejemplo de PHP </h1>

<?php

 #Enteros
 $a = 1234; # n�mero decimal
 $a = -123; # un n�mero negativo
 $a = 0123; # n�mero octal (equivalente al 83 decimal)
 $a = 0x12; /* n�mero hexadecimal (equivalente al 18 decimal) */

 //Flotantes o reales
 $b = 1.234; $b = 1.2e3;
 
 //Escribimos algo
 print "\n La a= $a y la b= $b <br> \n";
?>

</body>
</html>
