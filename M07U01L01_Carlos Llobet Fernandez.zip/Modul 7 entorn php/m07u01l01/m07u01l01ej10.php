<html>
<head> <title>Formulario</title></head>
<body>
<h1>Maquina tragaperras </h1>
 <?php
 echo "Escriba su apuesta en la maquina tragaperras y le dire si ha ganado";
?>
<form action="ej10.php" method="post">
    <div>
     cantidad: <input type="text" name="$aposta"> <br>
     <input type="submit" value="Apostar">
     <input type="submit" name="Esborra" value="borrar">
     </div>
 </form> 
 <?php
    if ($submit=true) {
    }else{clear();}
    
 ?>

</body>
</html>