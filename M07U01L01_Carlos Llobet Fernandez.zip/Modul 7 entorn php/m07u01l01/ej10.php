<html>
<head> <title>Formulario</title></head>
<body>
<h1>Tragaperras Resultado </h1>
    <table>
<?php
    $apost=$_POST['$aposta'];
    $i=rand(1,6);
    $t=rand(1,6);
    $s=rand(1,6);
    print "<img src='images/$i.png'></img><tr><img src='images/$t.png'></img><tr><img src='images/$s.png'></img>"
    ?>    
    </table>
<?php
    if (($i==$t) && ($i==$s) && ($t==$s) && ($i==1)){
        $apost=$apost*10;
        print "<br> Has guanyat $apost";
    }
    elseif(((($i==$t) || ($i==$s) || ($t==$s)) && ($i==1))) {
        $apost=$apost*4;
        print "<br> Has guanyat $apost";
    }
    elseif (($i==$t) && ($i==$s) && (($i!=1) && ($t!=1) && ($s!=1))){
        $apost=$apost*5;
        print "<br> Has guanyat $apost";
    }
    elseif((($i==1) || ($t==1) || ($s==1)) && (($i==$t) || ($i==$s) || ($t==$s)) && (($i!=1) || ($t!=1) || ($s!=1))){
        $apost=$apost*3;
        print "<br> Has guanyat $apost";
    }
    elseif((($i==$t) || ($i==$s) || ($t==$s)) && ($i!=1)) {
        $apost=$apost*2;
        print "<br> Has guanyat $apost";
    }
    elseif((($i==1) || ($t==1) || ($s==1))){
        print "<br> Has guanyat $apost";
    }
    else{
        print "<br> Has perdut";
    }
?>
<br>

<a href="m07u01l01ej10.php">Volver al formulario</a>
</body>
</html>