<html>
<head> <title>Ejemplo 5_1</title></head>
<body>
 <h1> Ejemplo de PHP </h1>
<?php

 
 $personal=$_POST ['personal'];
 $beer=$_POST ['beer'];
 
 print "<h2>Hola $personal[name],  ";
 print "tu email es $personal[email] y ";
 print "te gusta la cerveza $beer[0] </h2>\n";
?>
<br>

<a href="m07u01l01ej5.php">Volver al formulario</a>
</body>
</html>