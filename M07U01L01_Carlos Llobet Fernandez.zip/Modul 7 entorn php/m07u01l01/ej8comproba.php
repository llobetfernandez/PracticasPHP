<html>
<body>
<title>Comprovacio</title>
<h1>Hombres y Mujeres (Resultado 2)</h1>
<?php
$max=count($_POST['nom']);
$nombre=$_POST['nom'];
$Hombre=$_POST['Hombre'];
$Mujer=$_POST['Mujer'];
$genero=$_POST['genero'];
$cadeHombre="";
$cadeMujer="";
for ($n=0;$n<$max;$n++)
{
    if (empty($nombre[$n])==true) {
        $r++;
    }
    else {
        $p++;
        if(!empty($genero[$n])) {
                if($genero[$n]=="Hombre[$n]"){
                $cadeHombre=$cadeHombre . $nombre[$n];
                $t++;
            }
            else
            {
                if($genero[$n]=="Mujer[$n]"){
                    $cadeMujer=$cadeMujer . $nombre[$n];
                    $q++;
                }
            }
        }
    }
  
}
if ($r==$max){
    $p=0;
    $t=0;
    $q=0;
}

print "Se han recibido $p datos de un total de $max <br>";
print "Hombres $t: $cadeHombre <br>";
print "Mujeres $q: $cadeMujer <br>";
$cantidad=$max;
?>

<br>

<a href="m07u01l01ej8.php">Volver al formulario inicial</a>
<br>

<br>

<a href="ej8.php" method="post" value="$cantidad">Volver a la tabla</a>
</body>
</html>