<html>
<head> <title>Formulario de rectangulos</title></head>
<body>
 <h1> Rectangulos de estrellas formulario  </h1>

<form action="" method="post" >
    <div>
     cantidad: <input type="text" name="cantidad">
     <br>
     columnas: <input type="text" name="columnas">
     <br>
     filas: <input type="text" name="filas">
     <br>
     <input type="submit" name="Dibuja">
     <input type="submit" name="Esborra">
     </div>
 </form>
 <?php
 $cantidad=$_POST["cantidad"];
 $columnas=$_POST["columnas"];
 $filas=$_POST["filas"];
 if ($submit=true)  {
    echo "Numero de rectangulos: $cantidad <br>";
    echo "Numero de columnas: $columnas <br>";
    echo "Numero de filas: $filas <br>";
    for ($x=$cantidad; $x>0; $x=$x-1) {
        //for ($i=0; $i<; $i=$i-1) {
            for ($z=0; $z<$filas; $z=$z+1) {
                switch ($columnas) {
                    case 1:  echo " * "; print "<br>\n"; break;
                    case 2:  echo " * * "; print "<br>\n"; break;
                    case 3:  echo " * * * "; print "<br>\n"; break;
                    case 4:  echo " * * * * "; print "<br>\n"; break;
                    case 5:  echo " * * * * * "; print "<br>\n"; break;
                    case 6:  echo " * * * * * * "; print "<br>\n"; break;
                    case 7:  echo " * * * * * * * "; print "<br>\n"; break;
                    case 8:  echo " * * * * * * * * "; print "<br>\n"; break;
                    case 9:  echo " * * * * * * * * * "; print "<br>\n"; break;
                    case 10:  echo " * * * * * * * * * * "; print "<br>\n"; break;
                    default: echo "error valor"; print "<br>\n"; break;
                }
                
            }
            
            if ($i=$columnas) {
                print "<br>\n";
            
            }
        
        echo "<br>\n";
    }
}
else
{
 clear();
}    

?>
</body>
</html>