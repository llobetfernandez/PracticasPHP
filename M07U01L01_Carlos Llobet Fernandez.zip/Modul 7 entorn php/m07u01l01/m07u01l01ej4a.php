<html>
<head> <title>Ejemplo 4</title></head>
<body>
 <h1> Ejemplo de Formulario 1 </h1>
<p>Dame tu nombre !!!
<form action="ej4_1.php" method="post">
     Nombre: <input type="text" name="nombre">
     <input type="submit">
</form>
</body>
</html>