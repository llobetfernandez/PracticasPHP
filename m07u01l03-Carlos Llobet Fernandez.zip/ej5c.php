<html>
<body>
<title>Formularios</title>
<h1>Generador de habitacio (Formulario 2)</h1>
<?php
$cant=$_POST['cant'];
$checkes=$_POST['check'];
$i=$cant;
print "<form action='ej5d.php' method='post'>";
for ($t=0;$t<=$cant;$t++){
    if (isset($checkes[$t])){
                $k=$t+1;
                print "La habitacio $k esta ocupada per:"; print "<input type='text' name='usuari[$t]' /><br>";
            }
}
print "<input type='hidden' name='cant' value='$cant'>";
print "<input type='submit' name='Enviar' /><input type='reset' name='Borrar' />";
print "</form>";
?>
</body>
</html>