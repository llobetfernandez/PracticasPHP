<html>
<body>
<title>Formularios</title>
<h1>Generador de habitacio (Resultado)</h1>
<?php
$cant=$_POST['cant'];
$checkes=$_POST['checkes'];
$usuari=$_POST['usuari'];
$i=$cant;
$conta=0;
for ($t=0;$t<=$cant;$t++){
    if ($usuari[$t]<>''){
        $k=$t+1;
        print "La habitacio $k esta ocupada per: $usuari[$t] <br>";
    }
}
print "<a href='m07u01l03ej5.php'>Formulario inicial</a>";
?>
</body>
</html>