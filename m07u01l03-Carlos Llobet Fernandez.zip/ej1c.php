<html>
<body>
<title>Formularios</title>
<h1>Generador de formularios (Resultado)</h1>
<?php
$texto=$_POST['texto'];
$verificacion=$_POST['check'];
$m=count($_POST['texto']);
$n=count($_POST['q']);
$maxi=$_POST['maxi'];
print "Los valores recibidos son los siguientes: <br> <br>";
for ($i=0;$i<$maxi;$i++)
{
    $t=$i+1;
    if (!empty($texto[$i])){
        print "El campo $t del formulario vale $texto[$i] <br> <br>";    
    }
    else
    {   
        if(isset($verificacion[$i])){
            print "El campo $t del formulario vale ON <br> <br>";        
        }
        else
        {
            print "El campo $t del formulario vale OFF <br> <br>";    
        }
        
    }
}


?>
</body>
</html>