<html>
<head> <title>Generador de tabla</title></head>
<body>
<h1>Generador de tabla (Formulario 1)</h1>
<?php


    echo "Clicka en + o - para redimensionar la tabla.";
    print "<br>";

    $m=$_GET['fila'];
    $n=$_GET['columna'];
    print "<form method='get' action='m07u01l03ej3.php?fila=2 2&columna=2'>";
    if (($m=='') && ($n=='')) {
        $n=2;
        $m=2;
        if ($_GET['mash']=='+'){
            print "<form method='get' action='m07u01l03ej3.php?mash=+2&fila=$m2&columna=$n'>";
            $m=$_GET['fila'];
            $n=$_GET['columna'];
            $m++;
        }
        elseif ($_GET['masv']=='+'){
            print "<form method='get' action='m07u01l03ej3.php?masv=+2&fila=$m2&columna=$n'>";
            $m=$_GET['fila'];
            $n=$_GET['columna'];
            $n++;
        }
        elseif ($_GET['menosh']=='-'){
            print "<form method='get' action='m07u01l03ej3.php?menosh=-2&fila=$m2&columna=$n'>";
            $m=$_GET['fila'];
            $n=$_GET['columna'];
            $m--;
            if ($m==0){
                $m=1;
            }
        }
        elseif ($_GET['menosv']=='-'){
            print "<form method='get' action='m07u01l03ej3.php?menosv=-2&fila=$m2&columna=$n'>";
            $m=$_GET['fila'];
            $n=$_GET['columna'];
            $n--;
            if ($n==0){
                $n=1;
            }
        }
        else{
            print "<form method='get' action='m07u01l03ej3.php?fila=22&columna=2'>";
        }
        print "<table border='1px' border-style='solid'>";
        print "<tr border='1px'><td border='1px'>'    </td><td border='1px'>'    </td><td border='0px' rowspan='$m'><input type='submit' value='+' name='mash' /><input type='submit' value='-' name='menosh' /></td></tr>";
        print "<tr border='1px'><td border='1px'>'    </td><td border='1px'>'    </td></tr>";
        print "<tr border='0px'><td colspan='$n'><input type='submit' value='+' name='masv' /><input type='submit' value='-' name='menosv' /></td></tr>";
        print "</table>";
        print "<input type='hidden' name='fila' value='$m'><input type='hidden' name='columna' value='$n'>";
    }
    else{
        if ($_GET['mash']=='+'){
            print "<form method='get' action='m07u01l03ej3.php?mash=+2&fila=$m2&columna=$n'>";
            $m=$_GET['fila'];
            $n=$_GET['columna'];
            $m++;
            if ($m==9){
                $m=8;
            }
        }
        elseif ($_GET['masv']=='+'){
            print "<form method='get' action='m07u01l03ej3.php?masv=+2&fila=$m2&columna=$n'>";
            $m=$_GET['fila'];
            $n=$_GET['columna'];
            $n++;
            if ($n==9){
                $n=8;
            }
        }
        elseif ($_GET['menosh']=='-'){
            print "<form method='get' action='m07u01l03ej3.php?menosh=-2&fila=$m2&columna=$n'>";
            $m=$_GET['fila'];
            $n=$_GET['columna'];
            $m--;
            if ($m==0){
                $m=1;
            }
        }
        elseif ($_GET['menosv']=='-'){
            print "<form method='get' action='m07u01l03ej3.php?menosv=-2&fila=$m2&columna=$n'>";
            $m=$_GET['fila'];
            $n=$_GET['columna'];
            $n--;
            if ($n==0){
                $n=1;
            }
        }
        print "<table border='1px' border-style='solid'>";
        for ($mv=0;$mv<$n;$mv++){
            print "<tr border='1px'>";
            for ($mh=0;$mh<$m;$mh++){
                print "<td border='1px'>'    </td>";
            }
            if ($mv==0){
                print "<td border='0px' rowspan='$m'><input type='submit' value='+' name='mash' /><input type='submit' value='-' name='menosh' /></td></tr>";
            }
            print "</tr>";
        }
        print "<tr border='0px'><td colspan='$n'><input type='submit' value='+' name='masv' /><input type='submit' value='-' name='menosv' /></td></tr>";
        print "</table>";
        print "<input type='hidden' name='fila' value='$m'><input type='hidden' name='columna' value='$n'>";
    }
   
?>
</form>
 
</body>
</html>