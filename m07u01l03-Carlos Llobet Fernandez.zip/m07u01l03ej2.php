<html>
<head> <title>Generador de select</title></head>
<body>
<h1>Generador de select (Formulario 1)</h1>
 <?php
 echo "Escribe un numero de controles select y cuantos elementos para los formularios.";
?>
<form action="ej2.php" method="post">
    <div>
     Numero de controles: <input type="text" name="cantidad" /> <br>
     Numero de opciones: <input type="text" name="opciones" /> <br>
     <input type="submit" name="Enviar" value="Enviar" />
     <input type="reset" name="Esborra" value="Borrar" />
     </div>
 </form> 
 <?php
    if ($submit=true) {
    }
    else{
        clear();
        
    }
    
 ?>

</body>
</html>