<html>
<head> <title>Generador de formularios</title></head>
<body>
 <h1>Generador de formularios (Formulario 2)</h1>
 <form action="ej1b.php" method="post">
<?php
    $cant=$_POST["cantidad"];
    print "<table>";
     for ($i=1;$i<=$cant;$i++){
        $t=$i-1;
        print  "<tr><td rowspan='2'> $i </td><td>Texto: </td><td> <input name='nom[$t]' /> </td></tr><tr><td>Tipo de control: </td><td>Texto: <input type='radio' name='control[$t]' value='texto[$t]' /> <br> Casilla de verificacion: <input type='radio' name='control[$t]' value='verificacion[$t]' /> </td></tr>"; print "<br>";
       
        }
    print "</table>";
        ?>
    
    <input type="submit" value="Enviar" />
    <input type="reset" value="Borrar" />
</form>
<br>

<a href="m07u01l03ej1.php">Volver al formulario</a>
</body>
</html>