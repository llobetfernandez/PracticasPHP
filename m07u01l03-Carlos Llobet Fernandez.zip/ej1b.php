<html>
<body>
<title>Formularios</title>
<h1>Generador de formularios (Formulario 3)</h1>
<?php
$max=count($_POST['control']);
$nombre=$_POST['nom'];
$texto=$_POST['texto'];
$verifica=$_POST['verificacion'];
$control=$_POST['control'];
print "<form action='ej1c.php' method='post'>";
print "<input type='hidden' name='maxi' value='$max' />";
print "<table>";
for ($n=0;$n<$max;$n++)
{
    if (empty($nombre[$n])==true) {
        $r++;
    }
    else {
        $p++;
        if(!empty($control[$n])) {
            if($control[$n]=="texto[$n]"){
                print "<tr><td>$nombre[$n] </td><td><input type='text' name='texto[$n]' value='$texto[$n]' /></tr>";
                print "<input type='hidden' name='nombre[$n]' />";
                $t++;
            }
            else
            {
                if($control[$n]=="verificacion[$n]"){
                    print "<tr><td>$nombre[$n] </td><td><input type='checkbox' name='check[$n]' value='$check[$n]' /></tr>";
                    print "<input type='hidden' name='nombre[$n]' />";
                    $q++;
                }
            }
        }
    }
  
}

print "<input type='hidden' name='q' value='$q' />";
if ($r==$max){
    $p=0;
    $t=0;
    $q=0;
}
print "</table>";
$cantidad=$max;
print "<input type='submit' value='Enviar' /> <input type='reset' value='Borrar' />";
print "</form>";
?>

<br>

<a href="m07u01l03ej1.php">Volver al formulario inicial</a>
<br>

<br>

<a href="ej1.php" method="post" value="$cantidad">Volver a la tabla</a>
</body>
</html>