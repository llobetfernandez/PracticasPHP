<html>
<head> <title>Generador de tabla check</title></head>
<body>
<h1>Generador de tabla check (Formulario 2)</h1>
<?php
    echo "Marque la casilla y contare cuantas ha marcado";
    print "<br>";
    $m=$_POST['fila'];
    $n=$_POST['columna'];
    print "<form method='post' action='ej4c.php'>";
    print "<table border='1px' border-style='solid'>";
    for ($mv=0;$mv<$m;$mv++){
        if ($mh==0){
            print "<tr border='1px'>";
            for ($th=0;$th<=$n;$th++){
                if ($th<>0){
                    print "<td border='1px'>$th</td>";    
                }
                else{
                    print "<td border='1px'></td>";        
                }
            }
            print "</tr>";
        }
        else{
            print "<tr border='1px'>";    
        }
        for ($mh=0;$mh<=$n;$mh++){
            if ($mh==0){
                $tv=$mv+1;
                print "<td border='1px'>$tv</td>";
            }
            else
            {
                $tmph=$mh-1;
                $tmpv=$mv;
                print "<td border='1px'><input type='checkbox' name='check[$tmpv][$tmph]' /></td>";
            }
        }
        print "</tr>";
    }
    print "</table>";
    print "<input type='hidden' name='maxi' value='$n' /><input type='hidden' name='cant' value='$m' />";
    print "<input type='submit' name='Enviar' value='Contar' /><input type='reset' name='Borrar' value='Borrar' />";
?>
</form>
 
</body>
</html>