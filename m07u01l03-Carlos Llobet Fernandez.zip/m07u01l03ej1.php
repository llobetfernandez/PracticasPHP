<html>
<head> <title>Generador de formularios</title></head>
<body>
<h1>Generador de formularios (Formulario 1)</h1>
 <?php
 echo "Escribe un numero de controles para los formularios.";
?>
<form action="ej1.php" method="post">
    <div>
     cantidad: <input type="text" name="cantidad" /> <br>
     <input type="submit" value="Comprobar" />
     <input type="reset" name="Esborra" value="Borrar" />
     </div>
 </form> 
 <?php
    if ($submit=true) {
    }
    else{
        clear();
        
    }
    
 ?>

</body>
</html>