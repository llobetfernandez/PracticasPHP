<html>
<head> <title>Generador de formularios</title></head>
<body>
 <h1>Generador de formularios (Formulario 2)</h1>
 <form action="ej2b.php" method="post">
<?php
    $cant=$_POST["cantidad"];
    $opciones=$_POST["opciones"];
    print "Escribe las opciones de cada control:";
    print "<table  style='border-style:double; border-width:1px'>";
    for ($n=1;$n<=$cant;$n++){
        $m=$n-1;
        print "<tr style='border-width:0px'><td></td><td>select n $n </td></tr><br>";
        for ($i=1;$i<=$opciones;$i++){
        $t=$i-1;
        print "<tr><td style='border-width:1px; font-weight:bold'>Opcion</td><td style='style='border-width:1px; aling:center;font-weight:bold'>Texto</td></tr>";
        print  "<tr><td style='border-width:1px;' > $i </td><td style='border-width:1px;' ><input type='text' name='val[$m][$t]' /></td></tr><br>";
        }
    }
    print "</table>";
    $maxi=$opciones;

    
    print "<input type='hidden' name='cant' value='$cant' /><input type='hidden' name='maxi'  value='$maxi' />";
?>
    <input type="submit" name="Enviar" value="Enviar" />
    <input type="reset" name="Borrar" value="Borrar" />
    
</form>
<br>

<a href="m07u01l03ej2.php">Volver al formulario</a>
</body>
</html>