<html>
<head> <title>Generador de tabla check</title></head>
<body>
<h1>Generador de tabla check (Formulario 2)</h1>
<?php
    echo "Marque la casilla de habitacion ocupada";
    print "<br>";
    $m=$_POST['fila'];
    print "<form method='post' action='ej5c.php'>";
    print "<table border='1px' border-style='solid'>";
    for ($mv=0;$mv<$m;$mv++){
        if ($mv==0){
            print "<tr border='1px'>";
            for ($th=0;$th<=$m;$th++){
                if ($th<>0){
                    print "<td border='1px'>$th</td>";    
                }
            }
            print "</tr>";
        }
        print "<td border='1px'><input type='checkbox' name='check[$mv]' /></td>";
    }
    print "</table>";
    print "<input type='hidden' name='cant' value='$m' />";
    print "<input type='submit' name='Enviar' value='Contar' /><input type='reset' name='Borrar' value='Borrar' />";
?>
</form>
 
</body>
</html>