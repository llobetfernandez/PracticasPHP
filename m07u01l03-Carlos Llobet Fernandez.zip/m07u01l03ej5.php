<html>
<head> <title>Generador de habitaciones</title></head>
<body>
<h1>Generador de habitaciones (Formulario 1)</h1>
 <?php
 echo "Escribe un numero de habitaciones entre 1 y 20.";
?>
<form action="m07u01l03ej5b.php" method="post">
    <div>
     Numero de habitaciones: <input type="text" name="fila" /> <br>
     <input type="submit" name="Enviar" value="Enviar" />
     <input type="reset" name="Esborra" value="Borrar" />
     </div>
 </form> 
 <?php
    if ($submit=true) {
    }
    else{
        clear();
        
    }
    
 ?>

</body>
</html>