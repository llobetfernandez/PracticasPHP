<html>
<head> <title>Generador de check</title></head>
<body>
<h1>Generador de check (Formulario 1)</h1>
 <?php
 echo "Escribe un numero de filas y columnas entre 4 y 15.";
?>
<form action="m07u01l03ej4b.php" method="post">
    <div>
     Numero de filas: <input type="text" name="fila" /> <br>
     Numero de columnas: <input type="text" name="columna" /> <br>
     <input type="submit" name="Enviar" value="Enviar" />
     <input type="reset" name="Esborra" value="Borrar" />
     </div>
 </form> 
 <?php
    if ($submit=true) {
    }
    else{
        clear();
        
    }
    
 ?>

</body>
</html>