<html>
<body>
<title>Formularios</title>
<h1>Generador de select (Resultado)</h1>
<?php
$maxi=$_POST['maxi'];
$cant=$_POST['cant'];
$checkes=$_POST['check'];
$i=$cant;
$d=$maxi;
$td=0;
$conta=1;
$p=0;
$t=0;
    foreach ($checkes as $cant => $value1){
        foreach($value1 as $maxi => $value){
            if (isset($checkes)){
                $t++;
            }
            if (!isset($checkes)) {
                $temp[$p]=0;
                $p++;
                echo "hola p:$p";
            }
        
            if (($td<=$d) && ($t<>0)){
                $temp[$p]=$t;
            }
            elseif (($td>$d) && ($t<>0)){
            $td=0;
            $temp[$p]=$t;
            }
            $td++;
            
            echo "temp:$temp[$p] p:$p";
        }
        echo "<br>temp:$temp[$p] p:$p<br>";
        $p++;
        $q=$t;
        $t=0;
    }
for ($p=0;$p<$i;$p++){
    if ($temp[$p]==''){
        $temp[$p]=0;
    }
    print "El resultado de la fila $conta es de: $temp[$p] checkeados.<br>";
    $conta++;
}
?>
<br>

<a href="m07u01l03ej4.php">Volver al formulario inicial</a>
</body>
</html>