<html>
<body>
<title>Formularios</title>
<h1>Generador de select (Resultado)</h1>
<?php
$maxi=$_POST['maxi'];
$cant=$_POST['cant'];

print "Controles generados:";
print "<table style='border-style:double; border-width:1px'>";
print "<tr style='font-weight:bold'><td style='border-style:double; border-width:1px'>Numero</td><td style='border-style:double; border-width:1px'>Control select</td></tr>";
$opciones = $_POST['val'];
foreach ($opciones as $maxi => $value1) {
    $n=$maxi+1;
   print "<tr><td style='border-style:double; border-width:1px'>$n</td><td style='border-style:double; border-width:1px'>";
   print "<select>";
   foreach ($value1 as $cant => $value) {
                        print "<option>$value</option>";
                            #  print $i . ' ' . $value .'<br>';  
   }
   print "</select></td></tr>";   
}
print "</table>";
?>
<br>

<a href="m07u01l03ej2.php">Volver al formulario inicial</a>
</body>
</html>