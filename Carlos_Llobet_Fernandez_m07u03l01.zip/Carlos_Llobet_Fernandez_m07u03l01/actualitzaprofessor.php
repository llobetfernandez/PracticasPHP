<html>
<title>Crea professor</title>
<body>
<h1>Dades del professor a actualitzar</h1>
    <form action='actualizapro2.php' method='POST'>
        Nombre: <input type='text' name='nombre' />
        <input type='submit' value='Buscar professor'>
    </form>
</body>
</html>