<html>
  <head>
  
   <link href="css/bootstrap.css" rel="stylesheet" type="text/css"/>
    <meta http-equiv="Content-type" content="text/html;charset=UTF-8">
    <title>LLobet</title>
    <link href="jTable/themes/redmond/jquery-ui-1.8.16.custom.css" rel="stylesheet" type="text/css" />
    <link href="jTable/themes/lightcolor/blue/jtable.css" rel="stylesheet" type="text/css" />
  
    <script src="jTable/scripts/jquery-1.6.4.min.js" type="text/javascript"></script>
    <script src="jTable/scripts/jquery-ui-1.8.16.custom.min.js" type="text/javascript"></script>
    <script src="jTable/scripts/jtable/jquery.jtable.js" type="text/javascript"></script>
    <script type="text/javascript" src="jTable/scripts/jquery-ui.1.11.2.min.js"></script> 

    
      <!-- Import CSS file for validation engine (in Head section of HTML) -->
    <link href="jTable/scripts/validationEngine/validationEngine.jquery.css" rel="stylesheet" type="text/css" />
 
    <!-- Import Javascript files for validation engine (in Head section of HTML) -->
    <script type="text/javascript" src="jTable/scripts/validationEngine/jquery.validationEngine.js"></script>
    <script type="text/javascript" src="jTable/scripts/validationEngine/jquery.validationEngine-en.js"></script>
   
	
  </head>
  <body>
      <div id="AssignaTableContainer" style="width:750px;">
          <script type="text/javascript">
            
            $(document).ready(function() {
                $('#AssignaTableContainer').jtable({
                    title: 'Tabla Asignatura',
                    actions: {
                        listAction: 'asignaturaccions.php?action=list',                  
                        createAction: 'asignaturaccions.php?action=create',
                        updateAction: 'asignaturaccions.php?action=update',
                        deleteAction: 'asignaturaccions.php?action=delete'
                    },
                    fields: {
                        codigo: {
                            key:true,
                            title: 'codigo',
                            create: true,
                            edit: true,
                            list: true
                        },
                        descripcion: {
                            title:'descripcion',
                            width:'40%',
                            create: true,
                            edit: true,
                            list: true
                        },
                        creditos: {
                            title:'creditos',
                            width: '20%',
                            create: true,
                            edit: true,
                            list: true
                        },
                        creditosp: {
                            title: 'creditosp',
                            width: '30%',
                            create: true,
                            edit: true,
                            list: true
                        }
                    }
                });
                $('#AssignaTableContainer').jtable('load');
            });
        </script>
      </div>
      <br/>
    </body>
</html>