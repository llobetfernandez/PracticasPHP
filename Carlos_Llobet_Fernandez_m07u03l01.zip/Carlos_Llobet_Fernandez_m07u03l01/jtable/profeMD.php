<html>
  <head>
   
   <link href="css/bootstrap.css" rel="stylesheet" type="text/css"/>
    <meta http-equiv="Content-type" content="text/html;charset=UTF-8">
    <title>LLobet</title>
    <link href="jTable/themes/redmond/jquery-ui-1.8.16.custom.css" rel="stylesheet" type="text/css" />
    <link href="jTable/themes/lightcolor/blue/jtable.css" rel="stylesheet" type="text/css" />
  
    <script src="jTable/scripts/jquery-1.6.4.min.js" type="text/javascript"></script>
    <script src="jTable/scripts/jquery-ui-1.8.16.custom.min.js" type="text/javascript"></script>
    <script src="jTable/scripts/jtable/jquery.jtable.js" type="text/javascript"></script>
    <script type="text/javascript" src="jTable/scripts/jquery-ui.1.11.2.min.js"></script> 

    
      <!-- Import CSS file for validation engine (in Head section of HTML) -->
    <link href="jTable/scripts/validationEngine/validationEngine.jquery.css" rel="stylesheet" type="text/css" />
 
    <!-- Import Javascript files for validation engine (in Head section of HTML) -->
    <script type="text/javascript" src="jTable/scripts/validationEngine/jquery.validationEngine.js"></script>
    <script type="text/javascript" src="jTable/scripts/validationEngine/jquery.validationEngine-en.js"></script>
    
  </head>
  <body>
      <div id="ProfeTableContainer" style="width:750px;">
          <script type="text/javascript">
            $(document).ready(function() {
                $('#ProfeTableContainer').jtable({
                    title: 'Tabla professores',
                        paging: true,
                        pageSize:3,
                        sorting: true,
                        defaultSorting: 'dni ASC',
                    actions: {
                        listAction: 'profeaccions.php?action=list',                  
                        createAction: 'profeaccions.php?action=create',
                        updateAction: 'profeaccions.php?action=update',
                        deleteAction: 'profeaccions.php?action=delete'
                    },
                    fields: {
                        dni: {
                            key:true,
                            title: 'DNI',
                            create: true,
                            edit: true,
                            list: true
                        },
                        nombre: {
                            title:'Nombre',
                            width:'40%',
                            create: true,
                            edit: true,
                            list: true
                        },
                        categoria: {
                            title:'Categoria',
                            width: '20%',
                            create: true,
                            edit: true,
                            list: true
                        },
                        ingreso: {
                            title: 'Fecha ingreso',
                            width: '50%',
                            type: 'date',
                            create: true,
                            edit: true,
                            list: true
                        },
                        Assig:{
                        
                            title:'Assig',
                            width:'5%',
                            sorting:false,
                            edit:false,
                            create:false,
                            listClass:'child-opener-image-column',
                            display: function(AssigData){
                                var $img=$('<img class="child-opener-image" src="loading.gif" title="Editar assignatures" />');
                                $img.click(function(){
                                    $('#ProfeTableContainer').jtable('openChildTable', $img.closest('tr'), {title: AssigData.record.nombre + ' - Assignatures',
                                    actions: {
                                        listAction: 'profeaccionsMD.php?action=list&dni=' + AssigData.record.dni,
                                        createAction: 'profeaccionsMD.php?action=create&dni=' + AssigData.record.dni,
                                        updateAction: 'profeaccionsMD.php?action=update&dni=' + AssigData.record.dni,
                                        deleteAction: 'profeaccionsMD.php?action=delete&dni=' + AssigData.record.dni
                                    },
                                    fields: {
                                    dni: {
                                        type:'hidden',
                                        defaultValue: AssigData.record.dni,
                                        key: true,
                                        title:'DNI'
                                        },
                                    codigo: {
                                        title:'asignatura',
                                        key: true,
                                        width:'10%',
                                        options:'profeaccionsMD.php?action=getAssigid',
                                        create: true,
                                        edit: true,
                                        list: true
                                        }
                                    }
                                        
                                    },
                                    function (data) {
                                        data.childTable.jtable('load');
                                    }
                            )
                            });
                            return $img; 
                        }
                    }
                }
            });
            $('#ProfeTableContainer').jtable('load');
        });
        </script>
      </div>
      <br/>
    </body>
</html>