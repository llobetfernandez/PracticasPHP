<?php
try{
    $conf=mysql_connect('dawllobetfernandez.es.mysql','dawllobetfernan','CEjsmJtb');
    mysql_select_db ('dawllobetfernan', $conf);
      
    if($_GET["action"]=="list")
       {
           $result = mysql_query("SELECT * FROM coordinadores;");
           $rows=array();
           while($row = mysql_fetch_array($result))
           {
               $rows[]=$row;
           }
           $jTableResult=array();
           $jTableResult['Result']= "OK";
           $jTableResult['Records']=$rows;
           print json_encode($jTableResult);
       }
       
    else if($_GET["action"]=="create")
    {
        $result=mysql_query("INSERT INTO coordinadores (dni, nombre, dpto, asig) VALUES ('".$_POST['dni']. "','".$_POST['nombre']."','".$_POST['dpto']."','".$_POST['asig']."')");
        
        $result=mysql_query("SELECT * FROM coordinadores WHERE dni='".$_POST['dni']."'");
        $row=mysql_fetch_array($result);
        $jTableResult=array();
        $jTableResult['Result']='OK';
        $jTableResult['Records']=$row;
        print json_encode($jTableResult);
    }
    else if ($_GET["action"]=="update")
    {
        $result=mysql_query("UPDATE coordinadores SET dni='".$_POST['dni']."', nombre='".$_POST['nombre']."', dpto='".$_POST['dpto']."', asig='".$_POST['asig']."' WHERE dni='".$_POST['dni']."'");
        $jTableResult=array();
        $jTableResult['Result']='OK';
        print json_encode($jTableResult);
    }
    else if ($_GET["action"]=="delete")
    {
        $result=mysql_query ("DELETE FROM coordinadores WHERE dni='".$_POST['dni']."'");
        $jTableResult=array();
        $jTableResult['Result']='OK';
        print json_encode($jTableResult);
    }
    mysql_close($conf);
}
catch(Exception $ex)
{
    $jTableResult=array();
    $jTableResult['Result']="Error";
    $jTableResult['Message']=$ex -> getMessage();
    print json_encode($jTableResult);
}
?>