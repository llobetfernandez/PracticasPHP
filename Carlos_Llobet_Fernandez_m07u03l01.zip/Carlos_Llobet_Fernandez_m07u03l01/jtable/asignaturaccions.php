<?php
try{
    $conf=mysql_connect('dawllobetfernandez.es.mysql','dawllobetfernan','CEjsmJtb');
    mysql_select_db ('dawllobetfernan', $conf);
      
    if($_GET["action"]=="list")
       {
           $result = mysql_query("SELECT * FROM asignaturas;");
           $rows=array();
           while($row = mysql_fetch_array($result))
           {
               $rows[]=$row;
           }
           $jTableResult=array();
           $jTableResult['Result']= "OK";
           $jTableResult['Records']=$rows;
           print json_encode($jTableResult);
       }
       
    else if($_GET["action"]=="create")
    {
        $result=mysql_query("INSERT INTO asignaturas (codigo, descripcion, creditos, creditosp) VALUES ('".$_POST['codigo']. "','".$_POST['descripcion']."',".$_POST['creditos'].",".$_POST['creditosp'].")");
        
        $result=mysql_query("SELECT * FROM asignaturas WHERE codigo='".$_POST['codigo']."'");
        $row=mysql_fetch_array($result);
        $jTableResult=array();
        $jTableResult['Result']='OK';
        $jTableResult['Records']=$row;
        print json_encode($jTableResult);
    }
    else if ($_GET["action"]=="update")
    {
        $result=mysql_query("UPDATE asignaturas SET codigo='".$_POST['codigo']."', descripcion='".$_POST['descripcion']."', creditos=".$_POST['creditos'].", creditosp=".$_POST['creditosp']." WHERE codigo='".$_POST['codigo']."'");
        $jTableResult=array();
        $jTableResult['Result']='OK';
        print json_encode($jTableResult);
    }
    else if ($_GET["action"]=="delete")
    {
        $result=mysql_query ("DELETE FROM asignaturas WHERE codigo='".$_POST['codigo']."'");
        $jTableResult=array();
        $jTableResult['Result']='OK';
        print json_encode($jTableResult);
    }
    mysql_close($conf);
}
catch(Exception $ex)
{
    $jTableResult=array();
    $jTableResult['Result']="Error";
    $jTableResult['Message']=$ex -> getMessage();
    print json_encode($jTableResult);
}
?>