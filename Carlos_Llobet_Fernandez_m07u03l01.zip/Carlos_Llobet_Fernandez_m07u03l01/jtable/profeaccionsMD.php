<?php
try{
    $conb=mysql_connect('dawllobetfernandez.es.mysql','dawllobetfernan','CEjsmJtb');
    mysql_select_db ('dawllobetfernan', $conb);
      
    if($_GET["action"]=="list")
       {
           $result = mysql_query("SELECT prepara.dni, asignaturas.codigo FROM asignaturas, prepara WHERE prepara.dni='".$_GET['dni']."' AND prepara.asignatura=asignaturas.codigo;");
           $rows=array();
           while($row = mysql_fetch_array($result))
           {
               $rows[]=$row;
           }
           $jTableResult=array();
           $jTableResult['Result']= "OK";
           $jTableResult['Records']=$rows;
           print json_encode($jTableResult);
       }
    else if($_GET["action"]=="create")
    {
        
        $result=mysql_query("INSERT INTO prepara (dni, asignatura) VALUES ('".$_GET['dni']."','".$_POST['codigo']."');");
        $result=mysql_query("SELECT * FROM prepara WHERE dni='".$_GET['dni']."';");
    //    $result=mysql_query("SELECT * FROM prepara WHERE ((prepara.dni='".$_GET['dni']."') AND (prepara.asignatura='".$_POST['codigo']."'))");
        $row=mysql_fetch_array($result);
        
        $jTableResult=array();
        $jTableResult['Result']='OK';
        $jTableResult['Records']=$row;
        print json_encode($jTableResult);
    }
    else if ($_GET["action"]=="update")
    {
        $result=mysql_query("UPDATE prepara SET (dni='".$_GET['dni']."', asignatura='".$_POST['codigo']."') WHERE dni='".$_GET['dni']."' AND asignatura='".$_POST['codigo']."'");
        $jTableResult=array();
        $jTableResult['Result']='OK';
        print json_encode($jTableResult);
    }
    else if ($_GET["action"]=="delete")
    {
        $result=mysql_query ("DELETE FROM prepara WHERE (dni='".$_GET['dni']."') AND (asignatura='".$_POST['codigo']."')");
        $jTableResult=array();
        $jTableResult['Result']='OK';
        print json_encode($jTableResult);
    }
    else if ($_GET["action"]=="getAssigid")
    {
        $result=mysql_query("SELECT codigo, descripcion FROM asignaturas");
        $rows=array();
        while ($row=mysql_fetch_array($result)){
            $arr=array();
            $arr["DisplayText"]=utf8_encode($row['descripcion']);
            $arr["Value"]=$row['codigo'];
            $rows[]=$arr;
        }
        $jTableResult=array();
        $jTableResult['Result']='OK';
        $jTableResult['Options']=$rows;
        print json_encode($jTableResult);
    }
    mysql_close($conb);
}
catch(Exception $ex)
{
    $jTableResult=array();
    $jTableResult['Result']="Error";
    $jTableResult['Message']=$ex -> getMessage();
    print json_encode($jTableResult);
}