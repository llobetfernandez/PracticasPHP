<html>
  <head>
   
   <link href="css/bootstrap.css" rel="stylesheet" type="text/css"/>
    <meta http-equiv="Content-type" content="text/html;charset=UTF-8">
    <title>LLobet</title>
    <link href="jTable/themes/redmond/jquery-ui-1.8.16.custom.css" rel="stylesheet" type="text/css" />
    <link href="jTable/themes/lightcolor/blue/jtable.css" rel="stylesheet" type="text/css" />
  
    <script src="jTable/scripts/jquery-1.6.4.min.js" type="text/javascript"></script>
    <script src="jTable/scripts/jquery-ui-1.8.16.custom.min.js" type="text/javascript"></script>
    <script src="jTable/scripts/jtable/jquery.jtable.js" type="text/javascript"></script>
    <script type="text/javascript" src="jTable/scripts/jquery-ui.1.11.2.min.js"></script> 

    
      <!-- Import CSS file for validation engine (in Head section of HTML) -->
    <link href="jTable/scripts/validationEngine/validationEngine.jquery.css" rel="stylesheet" type="text/css" />
 
    <!-- Import Javascript files for validation engine (in Head section of HTML) -->
    <script type="text/javascript" src="jTable/scripts/validationEngine/jquery.validationEngine.js"></script>
    <script type="text/javascript" src="jTable/scripts/validationEngine/jquery.validationEngine-en.js"></script>
    
    
	
  </head>
  <body>
      <div id="AssignaTableContainer" style="width:750px;">
          <script type="text/javascript">
            
            $(document).ready(function() {
                $('#AssignaTableContainer').jtable({
                    title: 'Tabla Coordinadores',
                    actions: {
                        listAction: 'coordinaccions.php?action=list',                  
                        createAction: 'coordinaccions.php?action=create',
                        updateAction: 'coordinaccions.php?action=update',
                        deleteAction: 'coordinaccions.php?action=delete'
                    },
                    fields: {
                        dni: {
                            key:true,
                            title: 'dni',
                            unique: true,
                            create: true,
                            edit: true,
                            list: true
                        },
                        nombre: {
                            title:'nombre',
                            width:'40%',
                            unique: true,
                            create: true,
                            edit: true,
                            list: true
                        },
                        dpto: {
                            title:'dpto',
                            width: '20%',
                            create: true,
                            edit: true,
                            list: true
                        },
                        asig: {
                            title: 'asig',
                            width: '30%',
                            unique: true,
                            create: true,
                            edit: true,
                            list: true
                        }
                    }
                });
                $('#AssignaTableContainer').jtable('load');
            });
        </script>
      </div>
      <br/>
    </body>
</html>