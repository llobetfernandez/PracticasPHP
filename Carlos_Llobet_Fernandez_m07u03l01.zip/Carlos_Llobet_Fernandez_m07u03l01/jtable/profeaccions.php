<?php
try{
    $con=mysql_connect('dawllobetfernandez.es.mysql','dawllobetfernan','CEjsmJtb');
    mysql_select_db ('dawllobetfernan', $con);
    
    if($_GET["action"]=="list")
       {
           //$result = mysql_query("SELECT * FROM profesores");
           $result = mysql_query("SELECT * FROM profesores ORDER BY ".$_GET['jtSorting']." LIMIT ".$_GET['jtStartIndex'].",".$_GET['jtPageSize']);
           //$result = mysql_query("SELECT * FROM profesores ORDER BY dni ASC LIMIT 3, 10");//.$_GET['jtSorting']." LIMIT ".$_GET['jtStartIndex'].",".$_GET['jtPageSize']);
           $rows=array();
           while($row = mysql_fetch_array($result))
           {
               $rows[]=$row;
           }
           $jTableResult=array();
           $jTableResult['Result']= "OK";
           $jTableResult['Records']=$rows;
           print json_encode($jTableResult);
       }
       
    else if($_GET["action"]=="create")
    {
        $result=mysql_query("INSERT INTO profesores (dni, nombre, categoria, ingreso) VALUES ('".$_POST['dni']. "','".$_POST['nombre']."','".$_POST['categoria']."','".$_POST['ingreso']."')");
        //$result = mysql_query("SELECT * FROM profesores WHERE dni='".$_POST['dni']."' ORDER BY ".$_GET['jtSorting']." LIMIT ".$_GET['jtStartIndex'].",".$_GET['jtPageSize']);
        $result=mysql_query("SELECT * FROM profesores WHERE dni='".$_POST['dni']."'");
        $row=mysql_fetch_array($result);
        $jTableResult=array();
        $jTableResult['Result']='OK';
        $jTableResult['Records']=$row;
        print json_encode($jTableResult);
    }
    else if ($_GET["action"]=="update")
    {
        $result=mysql_query("UPDATE profesores SET (dni='".$_POST['dni']."',nombre='".$_POST['nombre']."',categoria='".$_POST['categoria']."',ingreso='".$_POST['ingreso']."') WHERE dni='".$_POST['dni']."'");
        //$result=mysql_query("UPDATE profesores SET (dni='".$_POST['dni']."', nombre='".$_POST['nombre']."', categoria=' ', ingreso='".$_POST['ingreso']."') WHERE dni='23'");
        $jTableResult=array();
        $jTableResult['Result']='OK';
        print json_encode($jTableResult);
    }
    else if ($_GET["action"]=="delete")
    {
        $result=mysql_query ("DELETE FROM profesores WHERE dni='".$_POST['dni']."'");
        $jTableResult=array();
        $jTableResult['Result']='OK';
        print json_encode($jTableResult);
    }
    mysql_close($con);
}
catch(Exception $ex)
{
    $jTableResult=array();
    $jTableResult['Result']="Error";
    $jTableResult['Message']=$ex -> getMessage();
    print json_encode($jTableResult);
}
?>