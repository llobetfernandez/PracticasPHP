<html>
  <head>
   
   <link href="css/bootstrap.css" rel="stylesheet" type="text/css"/>
    <meta http-equiv="Content-type" content="text/html;charset=UTF-8">
    <title>LLobet</title>
    <link href="jTable/themes/redmond/jquery-ui-1.8.16.custom.css" rel="stylesheet" type="text/css" />
    <link href="jTable/themes/lightcolor/blue/jtable.css" rel="stylesheet" type="text/css" />
  
    <script src="jTable/scripts/jquery-1.6.4.min.js" type="text/javascript"></script>
    <script src="jTable/scripts/jquery-ui-1.8.16.custom.min.js" type="text/javascript"></script>
    <script src="jTable/scripts/jtable/jquery.jtable.js" type="text/javascript"></script>
    <script type="text/javascript" src="jTable/scripts/jquery-ui.1.11.2.min.js"></script> 

    
      <!-- Import CSS file for validation engine (in Head section of HTML) -->
    <link href="jTable/scripts/validationEngine/validationEngine.jquery.css" rel="stylesheet" type="text/css" />
 
    <!-- Import Javascript files for validation engine (in Head section of HTML) -->
    <script type="text/javascript" src="jTable/scripts/validationEngine/jquery.validationEngine.js"></script>
    <script type="text/javascript" src="jTable/scripts/validationEngine/jquery.validationEngine-en.js"></script>
    
    
	
  </head>
  <body>
      <div id="ProfeTableContainer" style="width:750px;">
          <script type="text/javascript">
            
            $(document).ready(function() {
                $('#ProfeTableContainer').jtable({
                    title: 'Tabla professores',
                        paging: true,
                        pageSize: 3,
                        sorting: true,
                        defaultSorting: 'dni ASC',
                    actions: {
                        listAction: 'profeaccions.php?action=list',                  
                        createAction: 'profeaccions.php?action=create',
                        updateAction: 'profeaccions.php?action=update',
                        deleteAction: 'profeaccions.php?action=delete'
                    },
                    fields: {
                        dni: {
                            title: 'DNI',
                            key: true,
                            create: true,
                            edit: true,
                            list: true,
                            inputClass: 'valitate[required]'
                        },
                        nombre: {
                            title:'Nombre',
                            width:'40%',
                            create: true,
                            edit: true,
                            list: true,
                            inputClass: 'validate[required]'
                        },
                        categoria: {
                            title:'Categoria',
                            width: '20%',
                            create: true,
                            edit: true,
                            list: true,
                            inputClass: 'validate[required]'
                        },
                        ingreso: {
                            title: 'Fecha ingreso',
                            width: '30%',
                            type: 'date',
                            create: true,
                            edit: true,
                            list: true,
                            inputClass: 'validate[required,custom[date]]'
                        }
                    },
                    //Initialize validation logic when a form is created
                    formCreated: function (event, data) {
                        data.form.validationEngine();
                    },
                    //Validate form when it is being submitted
                    formSubmitting: function (event, data) {
                        return data.form.validationEngine('validate');
                    },
                    //Dispose validation logic when form is closed
                    formClosed: function (event, data) {
                        data.form.validationEngine('hide');
                        data.form.validationEngine('detach');
                    }
                });
                $('#ProfeTableContainer').jtable('load');
            });
        </script>
      </div>
      <br/>
    </body>
</html>