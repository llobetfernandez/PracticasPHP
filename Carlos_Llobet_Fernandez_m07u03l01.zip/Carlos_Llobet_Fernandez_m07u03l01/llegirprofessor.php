<html>
<title>Crea professor</title>
<body>
<h1>Dades del professor a buscar</h1>
    <form action='llegirpro2.php' method='POST'>
        Nombre: <input type='text' name='nombre' />
        <input type='submit' value='Llegir professor'>
    </form>
</body>
</html>