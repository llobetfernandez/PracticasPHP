<html>
<title>Manteniment CRUD de la taula professors</title>
<body>
<h1>Manteniment CRUD de la taula professors selecciona la accio a fer amb la taula professors.</h1>
<form method='post' action='creaprofessor.php'>    
    <input type='submit' id='$button1' value='crear professor' /><br>
</form>
<form method='post' action='llegirprofessor.php'>    
    <input type='submit' id='$button2' value='llegir professor' /> <br>
</form>
<form method='post' action='actualitzaprofessor.php'>    
    <input type='submit' id='$button3' value='actualitzar professor' /> <br>
</form>
<form method='post' action='borraprofessor.php'>    
    <input type='submit' id='$button4' value='borrar professor' /> <br>
</form>
</body>
</html>