<html>
<title>Crea professor</title>
<body>
<h1>Dades del nou professor</h1>
    <form action='actualizapro3.php' method='POST'>
    <?php
        $con=mysqli_connect('localhost','dawllobetfernan','CEjsmJtb','dawllobetfernan');
        if ($con==false)
        {
            echo "Fallo en conexion a MySQL: " . mysqli_connect_error();
        }
        else {
            $nombre=$_POST["nombre"];
            $res=mysqli_query($con, "SELECT * FROM profesores WHERE nombre='" . $nombre . "'");
            $row=mysqli_fetch_row($res);
            if ($row)
            {
                print "DNI: <input type='text' name='dni' value='$row[0]' />";
                print "Nombre: <input type='hidden' name='nombre' value='$nombre' />"; print $nombre; 
                print "Categoria: <input type='text' name='categoria' value='$row[2]' />";
                print "Fecha Ingreso: <input type='date' name='ingreso' value='$row[3]' />";
                print "<input type='submit' value='Actualitza dades'>";
            }
            else
            {
                print "No he trobat el professor a modificar.";
            }
            mysqli_close($con);
        }
        ?>
    </form>
</body>
</html>