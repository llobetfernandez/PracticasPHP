<html>
<title>Crea professor</title>
<body>
<h1>Dades del professor a actualitzar</h1>
    <form action='borrapro2.php' method='POST'>
        Nombre: <input type='text' name='nombre' />
        <input type='submit' value='Borrar professor'>
    </form>
</body>
</html>