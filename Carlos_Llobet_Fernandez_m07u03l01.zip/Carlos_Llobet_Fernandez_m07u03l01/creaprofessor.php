<html>
<title>Crea professor</title>
<body>
<h1>Dades del nou professor</h1>
    <form action='creapro2.php' method='POST'>
        DNI: <input type='text' name='dni' />
        Nombre: <input type='text' name='nombre' />
        Categoria: <input type='text' name='categoria' />
        Fecha Ingreso: <input type='date' name='ingreso' />
        <input type='submit' value='Crea professor'>
    </form>
</body>
</html>