<html>
<title>Crea professor</title>
<body>
<h1>Llegir del professor</h1>
    <?php
    $con=mysqli_connect('localhost','dawllobetfernan','CEjsmJtb','dawllobetfernan');
    if (mysqli_connect_errno())
    {
        echo "Fallo en conexion a MySQL: " . mysqli_connect_error();
    }
    $nombre=$_POST["nombre"];
    $res=mysqli_query($con,"DELETE FROM profesores WHERE nombre='" . $nombre ."'");
    if ($res)
    {
        print "Profesor $nombre borrado.";
    }
    else
    {
        print "No hay profesor a borrar.";
    }
    
    
    mysqli_close($con);
    ?>
</body>
</html>