<html>
<title>Crea professor</title>
<body>
<h1>Insercio del nou professor</h1>
    <?php
    $con=mysqli_connect('localhost','dawllobetfernan','CEjsmJtb','dawllobetfernan');
    if ($con==false)
    {
        echo "Fallo en conexion a MySQL: " . mysqli_connect_error();
    }
    else {
    $dni=$_POST["dni"];
    $nombre=$_POST["nombre"];
    $categoria=$_POST["categoria"];
    $ingreso=$_POST["ingreso"];
    mysqli_query($con,"INSERT INTO profesores (dni,nombre,categoria,ingreso) VALUES (" . $dni . ",'" . $nombre . "','" . $categoria . "','" . $ingreso . "')");
    
    print "insercio correcte.";
    
    mysqli_close($con);
    }
    ?>
</body>
</html>