<html>
<title>Crea professor</title>
<body>
<h1>Llegir del professor</h1>
    <?php
    $con=mysqli_connect('localhost','dawllobetfernan','CEjsmJtb','dawllobetfernan');
    if (mysqli_connect_errno())
    {
        echo "Fallo en conexion a MySQL: " . mysqli_connect_error();
    }
    $nombre=$_POST["nombre"];
    $res=mysqli_query($con,"SELECT * FROM profesores WHERE nombre='" . $nombre ."'");
    $row=mysqli_fetch_row($res);
    if ($row)
    {
        print "El resultado es: ";
        print_r ($row);
    }
    else
    {
        print "No hay resultado.";
    }
    
    
    mysqli_close($con);
    ?>
</body>
</html>